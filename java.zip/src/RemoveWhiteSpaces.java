import java.util.Scanner;

public class RemoveWhiteSpaces {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String line = sc.nextLine();
        StringBuilder orgString = new StringBuilder();
        for (int i = 0; i < line.length(); i++) {
            if (!String.valueOf(line.charAt(i)).equals(" ")){
                orgString.append(String.valueOf(line.charAt(i)));
            }
        }
        System.out.println(orgString);
    }
}
