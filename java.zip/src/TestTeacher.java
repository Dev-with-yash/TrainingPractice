import java.time.format.SignStyle;

public class TestTeacher {
    public static void main(String[] args) {

        Teacher t1 = new Teacher(1200L, "java Fundamentals", "Alex");
        Teacher t2 = new Teacher(800L, "RDBMS", "John");
        Teacher t3 = new Teacher(900L, "Networking", "sam");
        Teacher t4 = new Teacher(900L, "Python", "Maria");
        System.out.println(t1.toString());
        System.out.println(t2.toString());
        System.out.println(t3.toString());
        System.out.println(t4.toString());
    }
}
