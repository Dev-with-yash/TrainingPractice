import org.w3c.dom.css.Rect;

public class Rectangle
{
    public double length = 1.0f;
    public double breath = 1.0f;

    public double getArea(){
        return length * breath;
    }
    public double getPerimeter(){
        return 2 * (length + breath);
    }


    public double getLength() {
        return length;
    }

    public double getBreath() {
        return breath;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public void setBreath(double breath) {
        this.breath = breath;
    }

    @Override
    public String toString() {
        return "Rectangle{" +
                "length=" + length +
                ", breath=" + breath +
                '}';
    }

    public static void main(String[] args) {
        Rectangle r = new Rectangle();
        System.out.println(r.toString());
    }

}
