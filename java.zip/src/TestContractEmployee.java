public class TestContractEmployee {
    public static void main(String[] args) {
        ContractEmployee cemp1 = new ContractEmployee(102, "Jennifer", 16, 90);
        System.out.println("Hi"+cemp1.getName()+ ", your salary is $"+cemp1.calculateSalary());
    }
}
