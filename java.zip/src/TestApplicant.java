public class TestApplicant {
    public static void main(String[] args) throws InvalidAgeException, InvalidNameException, InvalidJobProfileException {
        Applicant ap1 = new Applicant("Jenny" ,25, "Clerk");
        Validator validator = new Validator();
        try{
            validator.validate(ap1);
            System.out.println("Application submitted successfully.");
        }
        catch (InvalidAgeException | InvalidNameException | InvalidJobProfileException e){
           System.out.println(e.getMessage());
        }
        Applicant ap2 = new Applicant("" ,23, "Manager");
        Validator validator2 = new Validator();
        try{
            validator.validate(ap2);
            System.out.println("Application submitted successfully.");
        }
        catch (InvalidAgeException | InvalidNameException | InvalidJobProfileException e){
            System.out.println(e.getMessage());
        }


    }
}
