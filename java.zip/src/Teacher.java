public class Teacher {
    public String teacherName;
    public String subject;
    public double salary;

    public Teacher(double salary, String subject, String teacherName) {
        this.salary = salary;
        this.subject = subject;
        this.teacherName = teacherName;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Teacher{" +
                "teacherName='" + teacherName + '\'' +
                ", subject='" + subject + '\'' +
                ", salary=" + salary +
                '}';
    }
}

