public class ContractEmployee {
    public int empid;
    public String name;
    public double wage;
    public float hoursWorked;

    public ContractEmployee(int empid, String name, double wage, float hoursWorked) {
        this.empid = empid;
        this.name = name;
        this.wage = wage;
        this.hoursWorked = hoursWorked;
    }

    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getWage() {
        return wage;
    }

    public void setWage(double wage) {
        this.wage = wage;
    }

    public float getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(float hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    public double calculateSalary(){
        double salary = hoursWorked * wage;
        return salary;
    }




}
