public class InvalidJobProfileException extends  Exception{
    public InvalidJobProfileException(String msg) {
        super(msg);
    }
}
