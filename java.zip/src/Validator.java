public class Validator {
    public boolean validateName(String name){
        if ( name == null || name == ""){
            return false;
        }
        else{
            return  true;
        }

    }
    public boolean validateJobProfile(String jobProfile) {
        String[] validJobProfiles = {"Associate", "Clerk", "Executive", "Officer"};
        for (String validProfile : validJobProfiles) {
            if (validProfile.equalsIgnoreCase(jobProfile)) {
                return true;
            }
        }
        return false;
    }
    public boolean validateAge(int age){
        if (age >= 18 && age <= 30){
            return true;
        }
        else {
            return false;
        }
    }
    public  void validate( Applicant applicant) throws InvalidNameException, InvalidJobProfileException, InvalidAgeException{
       if (!validateName(applicant.getName())){
            throw  new InvalidNameException("Name cannot be null or empty");

       }
        if (!validateAge(applicant.getAge())){
            throw  new InvalidAgeException("Age should between 18 and 30 inclusive");

        }
        if (!validateJobProfile(applicant.getJobProfile())){
            throw  new InvalidJobProfileException("job profile should be 4 mentioned above");

        }

    }

}
