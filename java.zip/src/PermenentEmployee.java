public class PermenentEmployee {
    public int empid;
    public String name;
    public double basicPay;
    public double hra;
    public float experience;

    public PermenentEmployee(int empid, double basicPay, String name, float experience, double hra) {
        this.empid = empid;
        this.basicPay = basicPay;
        this.name = name;
        this.experience = experience;
        this.hra = hra;
    }

    public double calculateMonthlySalary(){
        double variableComponent = 0f;

        if (experience < 3){
            variableComponent = 0f;
        }
        else if (experience >=3 && experience < 5){
            variableComponent = 5f;
        }
        else if (experience >=5 && experience < 10){
            variableComponent = 7f;
        }
        else if (experience >=10){
            variableComponent = 12f;
        }
        else {
            variableComponent = 0f;
        }

        double salary = basicPay + hra + ((variableComponent / 100)* basicPay);
        return salary;
    }


    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getBasicPay() {
        return basicPay;
    }

    public void setBasicPay(double basicPay) {
        this.basicPay = basicPay;
    }

    public double getHra() {
        return hra;
    }

    public void setHra(double hra) {
        this.hra = hra;
    }

    public float getExperience() {
        return experience;
    }

    public void setExperience(float experience) {
        this.experience = experience;
    }

    @Override
    public String toString() {
        return "PermenentEmployee{" +
                "empid=" + empid +
                ", name='" + name + '\'' +
                ", basicPay=" + basicPay +
                ", hra=" + hra +
                ", experience=" + experience +
                '}';
    }
}
