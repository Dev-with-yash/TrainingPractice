public class TestPermenentEmployee {
    public static void main(String[] args) {
        PermenentEmployee pemp1 = new PermenentEmployee(711211, 1850, "Rafel", 3.5f, 115);
        System.out.println("Hi" + pemp1.getName() + ", " + "your salary is $" + pemp1.calculateMonthlySalary());
    }
}
