public class Applicant {
    public String name;
    public String jobProfile;
    public int age;

    public Applicant(String name, int age, String jobProfile) {
        this.name = name;
        this.age = age;
        this.jobProfile = jobProfile;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getJobProfile() {
        return jobProfile;
    }

    public void setJobProfile(String jobProfile) {
        this.jobProfile = jobProfile;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Applicant{" +
                "name='" + name + '\'' +
                ", jobProfile='" + jobProfile + '\'' +
                ", age=" + age +
                '}';
    }
}
